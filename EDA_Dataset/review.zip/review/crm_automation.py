"""
Script to login and create/fill a form
"""

import time
import selenium
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait


def way2_launch_new_tab(driver,ref_link):
    """
    Function to launch the new case link 
    Parameters
    ----------
    driver : driver
        Chrome driver holding the data/allowing to extract data on the page.
    ref_link : str
        Link of the new case.

    Returns
    -------
    None.

    """
    new_driver = driver.get(ref_link)
    time.sleep(5)
    create_new = driver.find_elements_by_css_selector(".ui.linkedin.button")
    time.sleep(5)
    for elem in create_new:
        if elem.text =="Create":
            elem.click()
            fill_form(driver)
            break
    
def fill_form(driver):
    """
    Function to fill the values in the  form
    Parameters
    ----------
    driver : driver
        Chrome driver holding the data/allowing to extract data on the page.

    Returns
    -------
    None.

    """
    #Collect all the ui field as they conatin all the tags of form
    aasign_to_class =driver.find_elements_by_css_selector(".ui.field")
    for assign in aasign_to_class:
        tag_name = assign.find_element_by_tag_name("label").text
        if tag_name == "Title":
            title = assign.find_element_by_css_selector("input[value]")
            title.send_keys("Test_Case1")
        elif tag_name == "Access":
            access = driver.find_element_by_css_selector(".ui.small.fluid.positive.toggle.button")
            pass
        elif tag_name == "Assigned To":
            assign.find_element_by_css_selector(".ui.fluid.selection.dropdown").click()
            assign.find_element_by_css_selector(".visible.menu.transition").click()
        elif tag_name == "Contact":
            assign.find_element_by_css_selector(".ui.fluid.selection.dropdown").click()
            num = assign.find_element_by_css_selector("input[value]")
            num.send_keys("1234567890")
        elif tag_name == "Company":
            assign.find_element_by_css_selector(".ui.fluid.selection.dropdown").click()
            comp = assign.find_element_by_css_selector("input[value]")
            comp.send_keys("Dummy_company")  
        elif tag_name == "Deal":
            assign.find_element_by_css_selector(".ui.fluid.selection.dropdown").click()
            deal = assign.find_element_by_css_selector("input[value]")
            deal.send_keys("Dummy_deal")
        elif tag_name == "Type":
            assign.find_element_by_css_selector(".ui.selection.dropdown").click()
            count = assign.find_elements_by_css_selector(".item")
            #selct any option randomly using random module for now i am using index 1
            count[1].click()    
        elif tag_name == "Deadline":
            assign.find_element_by_css_selector(".react-datepicker__input-container").click()
            date = assign.find_element_by_css_selector("input[value]")
            date.send_keys("31/05/2021 08:30")
        elif tag_name == "Close Date":
            assign.find_element_by_css_selector(".react-datepicker__input-container").click()
            date = assign.find_element_by_css_selector("input[value]")
            date.send_keys("01/06/2021 08:30")
        elif tag_name == "Tags":
            assign.find_element_by_css_selector(".ui.fluid.multiple.search.selection.dropdown").click()
            tag = assign.find_element_by_css_selector("input[value]")
            tag.send_keys("Dummy_tag")
        elif tag_name == "Description":
            textarea = assign.find_element_by_tag_name("textarea")
            textarea.send_keys("Dummy_Description")
        elif tag_name == "Priority":
            assign.find_element_by_css_selector(".ui.selection.dropdown").click()
            priority = assign.find_elements_by_css_selector(".item")
            priority[1].click()
        elif tag_name == "Status":
            assign.find_element_by_css_selector(".ui.selection.dropdown").click()
            enquiry = assign.find_elements_by_css_selector(".item")
            enquiry[1].click()
        elif tag_name == "Identifier":
            id_no = assign.find_element_by_css_selector("input[value]")
            id_no.send_keys("101")

    create_new = driver.find_elements_by_css_selector(".ui.linkedin.button")
    time.sleep(2)
    for elem in create_new:
        if elem.text =="Save":
            elem.click()
            
            
def logout(driver):
    """
    FUnction to logout from the tool

    Parameters
    ----------
    driver : driver
        Chrome driver holding the data/allowing to extract data on the page.

    Returns
    -------
    None.

    """
    driver.find_element_by_css_selector(".ui.basic.button.floating.item.dropdown").click()
    drop_down = driver.find_element_by_css_selector(".menu.transition.visible")
    a_tag = drop_down.find_elements_by_tag_name("a")
    for tag in a_tag:
        logout = tag.find_element_by_css_selector(".text").text
        if logout == "Log Out":
            tag.click()
            
def launch_new_case(driver):
    driver.find_element_by_css_selector(".ui.fluid.large.blue.submit.button").click()
    time.sleep(5)#time to wait till page loads
    div_2_loop = driver.find_elements_by_class_name("menu-item-wrapper")
    for elem in div_2_loop:
        elems_val = elem.find_element_by_class_name("item-text")
        if elems_val.text == "Cases":
            ref_link = elem.find_element_by_tag_name("a").get_attribute("href")
            way2_launch_new_tab(driver,ref_link)
            break
        

if __name__ == "__main__":
    driver = webdriver.Chrome()
    #information for login
    url_path =r"https://ui.cogmento.com/"
    login_id =r"pabhi255@gmail.com"
    login_pass = r"Abhi.2896"
    content =driver.get(url_path)
    time.sleep(5)
    email_id= driver.find_element_by_name("email")
    password = driver.find_element_by_name("password")
    
    email_id.send_keys(login_id)
    password.send_keys(login_pass)
    launch_new_case(driver)
    time.sleep(10)
    logout(driver)